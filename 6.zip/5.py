from flask import Flask, url_for, render_template

app = Flask(__name__)


@app.route('/')
@app.route('/distribution')
def index(char):
    if char not in ['ol', 'ul']:
        return ValueError
    return render_template('base.html',
                           val=char)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')