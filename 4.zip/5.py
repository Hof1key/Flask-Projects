from flask import Flask, url_for, render_template

app = Flask(__name__)


@app.route('/')
@app.route('/training/<char>')
def index(char='Заготовка'):
    return render_template('base.html',
                           prof=char,
                           science_f=url_for('static', filename='img/science.png'),
                           engine_f=url_for('static', filename='img/engine.png'),
                           css_f=url_for('static', filename='css/style.css'))


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')